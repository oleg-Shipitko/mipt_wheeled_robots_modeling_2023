Запуск докера с GUI:
sudo docker run -e DISPLAY=unix$DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix -it mobile-robotics

На хосте: 
xhost +si:localuser:root
